export class Item {
    name!: string;
    pid!: string;
    category!: string;
    ingredient!: string;
    price!: number;
    brand!: string;
    quantity!: string;
    origin!: string;

}